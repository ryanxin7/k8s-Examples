# Changelog

All notable changes to this library will be documented in this file.

Entries should be ordered as follows:

- [CHANGE]
- [FEATURE]
- [ENHANCEMENT]
- [BUGFIX]

Entries should include a reference to the pull request that introduced the change.

## 1.3.0

- [BUGFIX] Fix the storage heper functions to use the right properties (snake vs camel case) #1420
- [ENHANCEMENT] Add this changelog to the chart #1420
